package com.example.blurron.overlay

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import androidx.camera.view.PreviewView
import com.google.mlkit.vision.face.Face

class FaceOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val faces = mutableListOf<Face>()
    private var preview: PreviewView? = null

    private val dimPaint = Paint().apply {
        color = Color.parseColor("#66000000")
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    private val blockPaint = Paint().apply {
        color = Color.BLACK
        alpha = 160
        isAntiAlias = true
    }

    fun updateFaces(newFaces: List<Face>, previewView: PreviewView) {
        faces.clear()
        faces.addAll(newFaces)
        this.preview = previewView
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (preview == null) return

        // leicht abdunkeln
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)

        // simple Zensurblöcke zeichnen
        for (f in faces) {
            val box = mapBoxToView(f.boundingBox)
            canvas.drawRoundRect(box, 24f, 24f, blockPaint)
        }
    }

    private fun mapBoxToView(src: Rect): RectF {
        val pv = preview ?: return RectF(src)
        val scaleX = width / pv.width.toFloat().coerceAtLeast(1f)
        val scaleY = height / pv.height.toFloat().coerceAtLeast(1f)
        return RectF(src.left * scaleX, src.top * scaleY, src.right * scaleX, src.bottom * scaleY)
    }
}